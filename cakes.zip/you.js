
document.getElementById("formbutton").addEventListener("click", myfuunc); 
document.getElementById("formbutton2").addEventListener("click", myfuuc); 
function myfuunc(){
    
    console.log("hello");
document.getElementById("formbro").style.display = "block";
document.getElementById("logins").innerHTML = "login";
document.getElementById("logintext").innerHTML = "login Here";
}
function myfuuc(){
    document.getElementById("formbro").style.display = "block";
    document.getElementById("logins").innerHTML = "Signup";
    document.getElementById("logintext").innerHTML = "Signup Here";
}
function openPopup() {
    var popup = document.getElementById("popup");
    popup.style.display = "block";
}

function closePopup() {
    var popup = document.getElementById("popup");
    popup.style.display = "none";
}